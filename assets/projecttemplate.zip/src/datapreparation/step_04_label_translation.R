# Translating relevant labels and domains to english --------------------------

# mytable$x_var_1 <- plyr::mapvalues(mytable$x_var_1, 
#                                    c('Other_Language_Column_Name1', 
#                                      'Other_Language_Column_Name2', 
#                                      'Other_Language_Column_Name3'),
#                                    c('English_Column_Name1', 
#                                      'English_Column_Name2', 
#                                      'English_Column_Name3'))
