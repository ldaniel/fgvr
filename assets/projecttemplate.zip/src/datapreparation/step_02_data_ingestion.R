# performing data loading -----------------------------------------------------
dataDirectory <- "data/raw/"

mytable <- read.csv2(paste(dataDirectory, "table.csv", sep = ""), stringsAsFactors = TRUE)

# special case for (big) tables to speedup data ingestion
if(!file.exists('data/processed/bigtable.feather')) {
  mybigtable   <- read.csv2(paste(dataDirectory, "bigrable.csv", sep = ""), stringsAsFactors = TRUE)
  write_feather(mybigtable, 'data/processed/bigtable.feather')
} else {
  mybigtable   <- read_feather('data/processed/bigtable.feather')
}

# performing data casting, column renaming and small touch-ups ----------------

# renaming columns in district table 
names(mytable)[names(mytable) == "column_name_1"] <- "x_var_1"
names(mytable)[names(mytable) == "column_name_2"] <- "x_var_2"
names(mytable)[names(mytable) == "column_name_3"] <- "x_var_3"
names(mytable)[names(mytable) == "column_name_4"] <- "y_var"

