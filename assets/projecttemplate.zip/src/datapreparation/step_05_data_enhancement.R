## ---- step_05_data_enhancement.R

# this step aims to improve the analysis by adding auxiliary information ------

# include your data enhancement code here
# mytable <- mytable %>% 
#   mutate(x_var_1 = as.string(x_var_1)
