All your plotted images and other imagery files goes here.
